# VinylCollectionApp

Android приложение для коллекции винила с такими функциями:

- база данных пластинок (Room)
- добавление и редактирование записи
- поиск по коллекции
- сканер штрихкода (CameraX + ML Kit)
- OCR фото конверта (ML Kit Text Recognition)
- автопоиск релиза в Discogs
- оценка стоимости коллекции по найденным Discogs marketplace stats

## Важно про Discogs

Для автопоиска и оценки стоимости нужен токен Discogs.

### Как задать токен
В **GitHub Actions Secrets** или локально в `gradle.properties` / `~/.gradle/gradle.properties` добавь:

```properties
DISCOGS_TOKEN=твой_токен
```

Если токен не задан, приложение соберётся, но поиск Discogs вернёт понятную ошибку.

## Какой APK использовать
Используй **release APK**, а не `app-debug.apk`.
