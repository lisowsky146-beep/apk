package com.example.vinylcollection.ui.components

import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.vinylcollection.ui.viewmodel.UiMessage

@Composable
fun MessageBar(
    message: UiMessage,
    onClear: () -> Unit
) {
    if (message.text.isNotBlank()) {
        AssistChip(
            onClick = onClear,
            label = { Text(message.text) },
            colors = AssistChipDefaults.assistChipColors()
        )
    }
}
