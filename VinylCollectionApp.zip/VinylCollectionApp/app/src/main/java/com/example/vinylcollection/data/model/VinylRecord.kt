package com.example.vinylcollection.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "records")
data class VinylRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val artist: String,
    val album: String,
    val year: Int? = null,
    val genre: String = "",
    val label: String = "",
    val format: String = "LP",
    val barcode: String = "",
    val notes: String = "",
    val coverImageUri: String = "",
    val discogsReleaseId: Int? = null,
    val discogsUrl: String = "",
    val estimatedMinValue: Double? = null,
    val estimatedMedianValue: Double? = null,
    val estimatedMaxValue: Double? = null,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
