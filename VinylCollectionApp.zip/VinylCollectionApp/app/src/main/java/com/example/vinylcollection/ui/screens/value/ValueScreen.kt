package com.example.vinylcollection.ui.screens.value

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.vinylcollection.ui.components.InfoCard
import com.example.vinylcollection.ui.viewmodel.VinylViewModel

@Composable
fun ValueScreen(viewModel: VinylViewModel) {
    val stats = viewModel.stats.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        InfoCard(
            title = "Records in database",
            value = stats.totalRecords.toString()
        )
        InfoCard(
            title = "Favorites",
            value = stats.favoritesCount.toString()
        )
        InfoCard(
            title = "Records with barcode",
            value = stats.withBarcodeCount.toString()
        )
        InfoCard(
            title = "Valued records",
            value = stats.valuedCount.toString()
        )
        InfoCard(
            title = "Estimated collection value",
            value = "$${"%.2f".format(stats.totalMedianValue)}",
            subtitle = "Сумма считается по сохранённым Discogs price values."
        )
    }
}
