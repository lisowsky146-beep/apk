package com.example.vinylcollection.ui.screens.collection

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.vinylcollection.ui.components.MessageBar
import com.example.vinylcollection.ui.components.RecordCard
import com.example.vinylcollection.ui.viewmodel.VinylViewModel

@Composable
fun CollectionScreen(viewModel: VinylViewModel) {
    val records = viewModel.filteredRecords.collectAsState().value
    val query = viewModel.searchQuery.collectAsState().value
    val message = viewModel.message.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("My Vinyl Collection")
        OutlinedTextField(
            value = query,
            onValueChange = viewModel::updateSearchQuery,
            label = { Text("Search artist, album, label, barcode") },
            modifier = Modifier.fillMaxWidth()
        )
        MessageBar(message = message, onClear = viewModel::clearMessage)

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(records, key = { it.id }) { record ->
                RecordCard(
                    record = record,
                    onFavoriteClick = { viewModel.toggleFavorite(record) },
                    onDeleteClick = { viewModel.deleteRecord(record) }
                )
            }
        }
    }
}
