package com.example.vinylcollection.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val VinylColors = lightColorScheme(
    primary = VinylGold,
    secondary = SoftBrown,
    background = Cream,
    surface = Cream,
    onPrimary = DarkBrown,
    onSecondary = Cream,
    onBackground = DarkBrown,
    onSurface = DarkBrown
)

@Composable
fun VinylCollectionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VinylColors,
        typography = Typography,
        content = content
    )
}
