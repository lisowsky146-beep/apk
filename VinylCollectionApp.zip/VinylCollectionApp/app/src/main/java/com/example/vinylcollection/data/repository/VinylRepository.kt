package com.example.vinylcollection.data.repository

import com.example.vinylcollection.data.local.ImportDraftDao
import com.example.vinylcollection.data.local.VinylDao
import com.example.vinylcollection.data.model.ImportDraft
import com.example.vinylcollection.data.model.VinylRecord

class VinylRepository(
    private val vinylDao: VinylDao,
    private val draftDao: ImportDraftDao
) {
    fun getAllRecords() = vinylDao.getAllRecords()
    fun getFavorites() = vinylDao.getFavorites()
    fun observeStats() = vinylDao.observeStats()
    fun search(query: String) = vinylDao.search(query)
    fun observeLatestDraft() = draftDao.observeLatestDraft()

    suspend fun insertRecord(record: VinylRecord): Long = vinylDao.insert(record)
    suspend fun updateRecord(record: VinylRecord) = vinylDao.update(record)
    suspend fun deleteRecord(record: VinylRecord) = vinylDao.delete(record)
    suspend fun getRecord(id: Int): VinylRecord? = vinylDao.getById(id)

    suspend fun saveDraft(draft: ImportDraft) = draftDao.insert(draft)
    suspend fun clearDraft() = draftDao.clear()
}
