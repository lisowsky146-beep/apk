package com.example.vinylcollection

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.vinylcollection.data.local.AppDatabase
import com.example.vinylcollection.data.repository.DiscogsRepository
import com.example.vinylcollection.data.repository.VinylRepository
import com.example.vinylcollection.network.DiscogsApi
import com.example.vinylcollection.ui.navigation.AppNavGraph
import com.example.vinylcollection.ui.theme.VinylCollectionTheme
import com.example.vinylcollection.ui.viewmodel.VinylViewModel
import com.example.vinylcollection.ui.viewmodel.VinylViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = AppDatabase.getDatabase(applicationContext)
        val api = DiscogsApi.create()
        val vinylRepository = VinylRepository(
            vinylDao = db.vinylDao(),
            draftDao = db.importDraftDao()
        )
        val discogsRepository = DiscogsRepository(api)

        setContent {
            VinylCollectionTheme {
                val vm: VinylViewModel = viewModel(
                    factory = VinylViewModelFactory(
                        vinylRepository = vinylRepository,
                        discogsRepository = discogsRepository
                    )
                )
                AppNavGraph(viewModel = vm)
            }
        }
    }
}
