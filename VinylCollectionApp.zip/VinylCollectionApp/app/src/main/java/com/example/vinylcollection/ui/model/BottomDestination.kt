package com.example.vinylcollection.ui.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.graphics.vector.ImageVector

sealed class BottomDestination(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    data object Collection : BottomDestination("collection", "Collection", Icons.Default.Home)
    data object Add : BottomDestination("add", "Add", Icons.Default.Add)
    data object Scan : BottomDestination("scan", "Scan", Icons.Default.CameraAlt)
    data object Discogs : BottomDestination("discogs", "Discogs", Icons.Default.Search)
    data object Value : BottomDestination("value", "Value", Icons.Default.PriceCheck)
}
