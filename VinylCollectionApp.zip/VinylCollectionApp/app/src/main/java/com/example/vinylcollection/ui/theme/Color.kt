package com.example.vinylcollection.ui.theme

import androidx.compose.ui.graphics.Color

val Cream = Color(0xFFF6F0E7)
val DarkBrown = Color(0xFF2A211C)
val VinylGold = Color(0xFFC89D3C)
val SoftBrown = Color(0xFF6C5E56)
