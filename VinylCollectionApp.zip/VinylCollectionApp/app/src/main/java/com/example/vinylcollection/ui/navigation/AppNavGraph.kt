package com.example.vinylcollection.ui.navigation

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.vinylcollection.ui.model.BottomDestination
import com.example.vinylcollection.ui.screens.add.AddRecordScreen
import com.example.vinylcollection.ui.screens.collection.CollectionScreen
import com.example.vinylcollection.ui.screens.discogs.DiscogsScreen
import com.example.vinylcollection.ui.screens.scan.ScanScreen
import com.example.vinylcollection.ui.screens.value.ValueScreen
import com.example.vinylcollection.ui.viewmodel.VinylViewModel

@Composable
fun AppNavGraph(viewModel: VinylViewModel) {
    val navController = rememberNavController()
    val items = listOf(
        BottomDestination.Collection,
        BottomDestination.Add,
        BottomDestination.Scan,
        BottomDestination.Discogs,
        BottomDestination.Value
    )
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                items.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute == item.route,
                        onClick = {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.startDestinationId) {
                                    saveState = true
                                }
                                restoreState = true
                                launchSingleTop = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = BottomDestination.Collection.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(BottomDestination.Collection.route) {
                CollectionScreen(viewModel)
            }
            composable(BottomDestination.Add.route) {
                AddRecordScreen(viewModel)
            }
            composable(BottomDestination.Scan.route) {
                ScanScreen(viewModel)
            }
            composable(BottomDestination.Discogs.route) {
                DiscogsScreen(viewModel)
            }
            composable(BottomDestination.Value.route) {
                ValueScreen(viewModel)
            }
        }
    }
}
