package com.example.vinylcollection.ui.screens.add

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.vinylcollection.ui.components.MessageBar
import com.example.vinylcollection.ui.viewmodel.VinylViewModel

@Composable
fun AddRecordScreen(viewModel: VinylViewModel) {
    val form = viewModel.addForm.collectAsState().value
    val message = viewModel.message.collectAsState().value
    val loading = viewModel.isLoading.collectAsState().value
    val latestDraft = viewModel.latestDraft.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Add / Edit Record")
        MessageBar(message = message, onClear = viewModel::clearMessage)

        if (loading) {
            CircularProgressIndicator()
        }

        if (latestDraft != null) {
            Text(
                "Imported draft: " +
                    latestDraft.discogsTitle.ifBlank {
                        "${latestDraft.suggestedArtist} — ${latestDraft.suggestedAlbum}"
                    }
            )
            latestDraft.priceMedian?.let {
                Text("Estimated Discogs value: $${"%.2f".format(it)}")
            }
            Button(
                onClick = viewModel::saveImportedDraftAsRecord,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save imported draft")
            }
        }

        OutlinedTextField(
            value = form.artist,
            onValueChange = { value -> viewModel.updateAddForm { current -> current.copy(artist = value) } },
            label = { Text("Artist") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = form.album,
            onValueChange = { value -> viewModel.updateAddForm { current -> current.copy(album = value) } },
            label = { Text("Album") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = form.year,
            onValueChange = { value -> viewModel.updateAddForm { current -> current.copy(year = value) } },
            label = { Text("Year") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = form.genre,
            onValueChange = { value -> viewModel.updateAddForm { current -> current.copy(genre = value) } },
            label = { Text("Genre") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = form.label,
            onValueChange = { value -> viewModel.updateAddForm { current -> current.copy(label = value) } },
            label = { Text("Label") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = form.format,
            onValueChange = { value -> viewModel.updateAddForm { current -> current.copy(format = value) } },
            label = { Text("Format") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = form.barcode,
            onValueChange = { value -> viewModel.updateAddForm { current -> current.copy(barcode = value) } },
            label = { Text("Barcode") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = form.notes,
            onValueChange = { value -> viewModel.updateAddForm { current -> current.copy(notes = value) } },
            label = { Text("Notes / OCR text") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = viewModel::saveRecordFromForm,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save record manually")
        }
    }
}
