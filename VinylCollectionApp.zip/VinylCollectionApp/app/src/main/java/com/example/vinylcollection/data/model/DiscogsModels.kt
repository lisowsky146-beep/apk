package com.example.vinylcollection.data.model

data class DiscogsSearchResponse(
    val results: List<DiscogsSearchResult> = emptyList()
)

data class DiscogsSearchResult(
    val id: Int,
    val title: String = "",
    val year: Int? = null,
    val country: String? = null,
    val genre: List<String>? = null,
    val label: List<String>? = null,
    val barcode: List<String>? = null,
    val thumb: String? = null,
    val resource_url: String? = null
)

data class DiscogsReleaseResponse(
    val id: Int,
    val title: String = "",
    val year: Int? = null,
    val artists: List<DiscogsArtist> = emptyList(),
    val labels: List<DiscogsLabel> = emptyList(),
    val genres: List<String> = emptyList(),
    val formats: List<DiscogsFormat> = emptyList(),
    val uri: String? = null,
    val notes: String? = null
)

data class DiscogsArtist(
    val name: String = ""
)

data class DiscogsLabel(
    val name: String = ""
)

data class DiscogsFormat(
    val name: String = ""
)

data class DiscogsMarketplaceStats(
    val lowest_price: DiscogsPriceValue? = null,
    val num_for_sale: Int? = null,
    val blocked_from_sale: Boolean? = null
)

data class DiscogsPriceValue(
    val currency: String = "USD",
    val value: Double = 0.0
)
