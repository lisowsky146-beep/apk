package com.example.vinylcollection.util

data class ParsedRecordHint(
    val artist: String = "",
    val album: String = "",
    val year: Int? = null,
    val label: String = ""
)

object TextParser {
    fun parseCoverText(text: String): ParsedRecordHint {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val year = Regex("""(19|20)\d{2}""").find(text)?.value?.toIntOrNull()

        val artist = lines.getOrNull(0).orEmpty()
        val album = lines.getOrNull(1).orEmpty()

        val possibleLabel = lines.firstOrNull {
            it.contains("records", ignoreCase = true) ||
                it.contains("music", ignoreCase = true) ||
                it.contains("studio", ignoreCase = true)
        }.orEmpty()

        return ParsedRecordHint(
            artist = artist,
            album = album,
            year = year,
            label = possibleLabel
        )
    }
}
