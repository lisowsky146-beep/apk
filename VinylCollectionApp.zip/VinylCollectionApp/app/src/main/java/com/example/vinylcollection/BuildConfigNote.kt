package com.example.vinylcollection

// Этот файл ничего не делает.
// Он нужен только как заметка: токен Discogs попадает в BuildConfig.DISCOGS_TOKEN из Gradle.
