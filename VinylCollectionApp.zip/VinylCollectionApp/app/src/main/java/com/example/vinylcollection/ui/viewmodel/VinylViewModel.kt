package com.example.vinylcollection.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.vinylcollection.data.model.DiscogsSearchResult
import com.example.vinylcollection.data.model.ImportDraft
import com.example.vinylcollection.data.model.VinylRecord
import com.example.vinylcollection.data.repository.DiscogsRepository
import com.example.vinylcollection.data.repository.VinylRepository
import com.example.vinylcollection.util.OcrProcessor
import com.example.vinylcollection.util.TextParser
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AddFormState(
    val artist: String = "",
    val album: String = "",
    val year: String = "",
    val genre: String = "",
    val label: String = "",
    val format: String = "LP",
    val barcode: String = "",
    val notes: String = "",
    val coverImageUri: String = ""
)

data class UiMessage(
    val text: String = "",
    val isError: Boolean = false
)

class VinylViewModel(
    private val vinylRepository: VinylRepository,
    private val discogsRepository: DiscogsRepository
) : ViewModel() {

    val records = vinylRepository.getAllRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val favorites = vinylRepository.getFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val stats = vinylRepository.observeStats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), com.example.vinylcollection.data.model.CollectionStats())

    val latestDraft = vinylRepository.observeLatestDraft()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _searchQuery = kotlinx.coroutines.flow.MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val filteredRecords = combine(records, _searchQuery) { records, query ->
        if (query.isBlank()) records
        else records.filter {
            it.artist.contains(query, true) ||
                it.album.contains(query, true) ||
                it.label.contains(query, true) ||
                it.barcode.contains(query, true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _discogsResults = kotlinx.coroutines.flow.MutableStateFlow<List<DiscogsSearchResult>>(emptyList())
    val discogsResults: StateFlow<List<DiscogsSearchResult>> = _discogsResults

    private val _discogsQuery = kotlinx.coroutines.flow.MutableStateFlow("")
    val discogsQuery: StateFlow<String> = _discogsQuery

    private val _addForm = kotlinx.coroutines.flow.MutableStateFlow(AddFormState())
    val addForm: StateFlow<AddFormState> = _addForm

    private val _message = kotlinx.coroutines.flow.MutableStateFlow(UiMessage())
    val message: StateFlow<UiMessage> = _message

    private val _isLoading = kotlinx.coroutines.flow.MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateDiscogsQuery(query: String) {
        _discogsQuery.value = query
    }

    fun updateAddForm(transform: (AddFormState) -> AddFormState) {
        _addForm.value = transform(_addForm.value)
    }

    fun applyBarcode(barcode: String) {
        _addForm.value = _addForm.value.copy(barcode = barcode)
        _message.value = UiMessage("Штрихкод распознан: $barcode")
    }

    fun clearMessage() {
        _message.value = UiMessage()
    }

    fun saveRecordFromForm() {
        val form = _addForm.value
        if (form.artist.isBlank() || form.album.isBlank()) {
            _message.value = UiMessage("Artist и Album обязательны.", isError = true)
            return
        }

        viewModelScope.launch {
            vinylRepository.insertRecord(
                VinylRecord(
                    artist = form.artist.trim(),
                    album = form.album.trim(),
                    year = form.year.toIntOrNull(),
                    genre = form.genre.trim(),
                    label = form.label.trim(),
                    format = form.format.trim(),
                    barcode = form.barcode.trim(),
                    notes = form.notes.trim(),
                    coverImageUri = form.coverImageUri.trim()
                )
            )
            _addForm.value = AddFormState()
            _message.value = UiMessage("Запись сохранена.")
        }
    }

    fun toggleFavorite(record: VinylRecord) {
        viewModelScope.launch {
            vinylRepository.updateRecord(record.copy(isFavorite = !record.isFavorite))
        }
    }

    fun deleteRecord(record: VinylRecord) {
        viewModelScope.launch {
            vinylRepository.deleteRecord(record)
            _message.value = UiMessage("Запись удалена.")
        }
    }

    fun searchDiscogs() {
        val query = _discogsQuery.value.trim()
        if (query.isBlank()) {
            _message.value = UiMessage("Введи поисковый запрос для Discogs.", isError = true)
            return
        }

        viewModelScope.launch {
            runCatching {
                _isLoading.value = true
                discogsRepository.searchByQuery(query)
            }.onSuccess {
                _discogsResults.value = it
                if (it.isEmpty()) {
                    _message.value = UiMessage("Ничего не найдено в Discogs.")
                }
            }.onFailure {
                _message.value = UiMessage(it.message ?: "Ошибка поиска Discogs.", isError = true)
            }
            _isLoading.value = false
        }
    }

    fun searchDiscogsByBarcode(barcode: String) {
        if (barcode.isBlank()) {
            _message.value = UiMessage("Сначала отсканируй штрихкод.", isError = true)
            return
        }
        viewModelScope.launch {
            runCatching {
                _isLoading.value = true
                discogsRepository.searchByBarcode(barcode)
            }.onSuccess {
                _discogsResults.value = it
                _discogsQuery.value = barcode
                _message.value = if (it.isEmpty()) UiMessage("По штрихкоду ничего не найдено.") else UiMessage("Найдены релизы: ${it.size}")
            }.onFailure {
                _message.value = UiMessage(it.message ?: "Ошибка поиска по штрихкоду.", isError = true)
            }
            _isLoading.value = false
        }
    }

    fun importDiscogsResult(result: DiscogsSearchResult) {
        viewModelScope.launch {
            runCatching {
                _isLoading.value = true
                val release = discogsRepository.getRelease(result.id)
                val lowestPrice = discogsRepository.getLowestPrice(result.id)
                val artist = release.artists.joinToString(", ") { it.name }.ifBlank {
                    result.title.substringBefore(" - ", "")
                }
                val album = release.title.substringAfter(" - ", release.title)
                val label = release.labels.firstOrNull()?.name.orEmpty()
                val genre = release.genres.firstOrNull().orEmpty()
                val format = release.formats.firstOrNull()?.name ?: "LP"

                _addForm.value = _addForm.value.copy(
                    artist = artist,
                    album = album,
                    year = release.year?.toString().orEmpty(),
                    genre = genre,
                    label = label,
                    format = format,
                    barcode = _addForm.value.barcode.ifBlank { result.barcode?.firstOrNull().orEmpty() },
                    notes = release.notes.orEmpty()
                )

                vinylRepository.saveDraft(
                    ImportDraft(
                        barcode = _addForm.value.barcode,
                        ocrText = latestDraft.value?.ocrText.orEmpty(),
                        suggestedArtist = artist,
                        suggestedAlbum = album,
                        suggestedYear = release.year,
                        suggestedLabel = label,
                        discogsReleaseId = result.id,
                        discogsTitle = result.title,
                        discogsThumb = result.thumb.orEmpty(),
                        priceMedian = lowestPrice
                    )
                )

                _message.value = UiMessage("Данные из Discogs подставлены в форму.")
            }.onFailure {
                _message.value = UiMessage(it.message ?: "Не удалось импортировать релиз.", isError = true)
            }
            _isLoading.value = false
        }
    }

    fun saveImportedDraftAsRecord() {
        val draft = latestDraft.value ?: run {
            _message.value = UiMessage("Нет импортированного черновика.", isError = true)
            return
        }

        viewModelScope.launch {
            val artist = if (addForm.value.artist.isNotBlank()) addForm.value.artist else draft.suggestedArtist
            val album = if (addForm.value.album.isNotBlank()) addForm.value.album else draft.suggestedAlbum

            if (artist.isBlank() || album.isBlank()) {
                _message.value = UiMessage("Недостаточно данных для сохранения.", isError = true)
                return@launch
            }

            vinylRepository.insertRecord(
                VinylRecord(
                    artist = artist,
                    album = album,
                    year = addForm.value.year.toIntOrNull() ?: draft.suggestedYear,
                    genre = addForm.value.genre,
                    label = if (addForm.value.label.isNotBlank()) addForm.value.label else draft.suggestedLabel,
                    format = addForm.value.format,
                    barcode = addForm.value.barcode.ifBlank { draft.barcode },
                    notes = addForm.value.notes.ifBlank { draft.ocrText },
                    coverImageUri = addForm.value.coverImageUri,
                    discogsReleaseId = draft.discogsReleaseId,
                    discogsUrl = if (draft.discogsReleaseId != null) "https://www.discogs.com/release/${draft.discogsReleaseId}" else "",
                    estimatedMinValue = draft.priceMedian,
                    estimatedMedianValue = draft.priceMedian,
                    estimatedMaxValue = draft.priceMedian
                )
            )
            _message.value = UiMessage("Импортированный релиз сохранён в базу.")
        }
    }

    fun processOcrImage(context: Context, uri: Uri) {
        viewModelScope.launch {
            runCatching {
                _isLoading.value = true
                val text = OcrProcessor.extractText(context, uri)
                val parsed = TextParser.parseCoverText(text)
                vinylRepository.saveDraft(
                    ImportDraft(
                        barcode = _addForm.value.barcode,
                        ocrText = text,
                        suggestedArtist = parsed.artist,
                        suggestedAlbum = parsed.album,
                        suggestedYear = parsed.year,
                        suggestedLabel = parsed.label
                    )
                )
                _addForm.value = _addForm.value.copy(
                    artist = parsed.artist.ifBlank { _addForm.value.artist },
                    album = parsed.album.ifBlank { _addForm.value.album },
                    year = parsed.year?.toString().orEmpty().ifBlank { _addForm.value.year },
                    label = parsed.label.ifBlank { _addForm.value.label },
                    coverImageUri = uri.toString(),
                    notes = if (text.length > 800) text.take(800) else text
                )
                text
            }.onSuccess {
                _message.value = UiMessage("OCR завершён. Текст распознан.")
            }.onFailure {
                _message.value = UiMessage(it.message ?: "Ошибка OCR.", isError = true)
            }
            _isLoading.value = false
        }
    }
}

class VinylViewModelFactory(
    private val vinylRepository: VinylRepository,
    private val discogsRepository: DiscogsRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return VinylViewModel(vinylRepository, discogsRepository) as T
    }
}
