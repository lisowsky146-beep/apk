package com.example.vinylcollection.data.sample

import com.example.vinylcollection.data.model.VinylRecord

object SampleRecords {
    val demo = listOf(
        VinylRecord(artist = "Pink Floyd", album = "The Dark Side of the Moon", year = 1973, genre = "Progressive Rock", label = "Harvest", barcode = "5099902987613"),
        VinylRecord(artist = "Nirvana", album = "Nevermind", year = 1991, genre = "Grunge", label = "DGC", barcode = "720642442517"),
        VinylRecord(artist = "Metallica", album = "Ride the Lightning", year = 1984, genre = "Thrash Metal", label = "Megaforce")
    )
}
