package com.example.vinylcollection.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "import_drafts")
data class ImportDraft(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val barcode: String = "",
    val ocrText: String = "",
    val suggestedArtist: String = "",
    val suggestedAlbum: String = "",
    val suggestedYear: Int? = null,
    val suggestedLabel: String = "",
    val discogsReleaseId: Int? = null,
    val discogsTitle: String = "",
    val discogsThumb: String = "",
    val priceMedian: Double? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
