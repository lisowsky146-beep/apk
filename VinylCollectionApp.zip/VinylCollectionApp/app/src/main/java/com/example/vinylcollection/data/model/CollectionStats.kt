package com.example.vinylcollection.data.model

data class CollectionStats(
    val totalRecords: Int = 0,
    val favoritesCount: Int = 0,
    val withBarcodeCount: Int = 0,
    val valuedCount: Int = 0,
    val totalMedianValue: Double = 0.0
)
