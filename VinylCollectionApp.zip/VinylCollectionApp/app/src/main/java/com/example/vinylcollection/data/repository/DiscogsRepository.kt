package com.example.vinylcollection.data.repository

import com.example.vinylcollection.BuildConfig
import com.example.vinylcollection.data.model.DiscogsReleaseResponse
import com.example.vinylcollection.data.model.DiscogsSearchResult
import com.example.vinylcollection.network.DiscogsApiService

class DiscogsRepository(
    private val api: DiscogsApiService
) {
    private fun tokenOrThrow(): String {
        val token = BuildConfig.DISCOGS_TOKEN.trim()
        require(token.isNotEmpty()) {
            "Добавь DISCOGS_TOKEN в gradle.properties или GitHub Secrets."
        }
        return token
    }

    suspend fun searchByBarcode(barcode: String): List<DiscogsSearchResult> {
        val token = tokenOrThrow()
        return api.searchReleases(
            token = token,
            type = "release",
            barcode = barcode,
            perPage = 10
        ).results
    }

    suspend fun searchByQuery(query: String): List<DiscogsSearchResult> {
        val token = tokenOrThrow()
        return api.searchReleases(
            token = token,
            type = "release",
            query = query,
            perPage = 20
        ).results
    }

    suspend fun getRelease(id: Int): DiscogsReleaseResponse {
        val token = tokenOrThrow()
        return api.getRelease(
            releaseId = id,
            token = token
        )
    }

    suspend fun getLowestPrice(releaseId: Int): Double? {
        val token = tokenOrThrow()
        return api.getMarketplaceStats(
            releaseId = releaseId,
            token = token
        ).lowest_price?.value
    }
}
