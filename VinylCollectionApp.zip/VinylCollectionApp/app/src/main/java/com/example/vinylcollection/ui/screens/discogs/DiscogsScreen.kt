package com.example.vinylcollection.ui.screens.discogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.vinylcollection.data.model.DiscogsSearchResult
import com.example.vinylcollection.ui.components.MessageBar
import com.example.vinylcollection.ui.viewmodel.VinylViewModel

@Composable
fun DiscogsScreen(viewModel: VinylViewModel) {
    val query = viewModel.discogsQuery.collectAsState().value
    val results = viewModel.discogsResults.collectAsState().value
    val loading = viewModel.isLoading.collectAsState().value
    val message = viewModel.message.collectAsState().value
    val barcode = viewModel.addForm.collectAsState().value.barcode

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Discogs auto-search")
        MessageBar(message = message, onClear = viewModel::clearMessage)

        OutlinedTextField(
            value = query,
            onValueChange = viewModel::updateDiscogsQuery,
            label = { Text("Artist, album, barcode") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = viewModel::searchDiscogs, modifier = Modifier.fillMaxWidth()) {
            Text("Search in Discogs")
        }

        Button(
            onClick = { viewModel.searchDiscogsByBarcode(barcode) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Search by scanned barcode")
        }

        if (loading) CircularProgressIndicator()

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(results, key = { it.id }) { result ->
                DiscogsResultCard(
                    result = result,
                    onImport = { viewModel.importDiscogsResult(result) }
                )
            }
        }
    }
}

@Composable
private fun DiscogsResultCard(
    result: DiscogsSearchResult,
    onImport: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(result.title)
            Text(
                listOfNotNull(
                    result.year?.toString(),
                    result.country,
                    result.genre?.firstOrNull(),
                    result.label?.firstOrNull()
                ).joinToString(" • ")
            )
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
                Text("Import into add form")
            }
        }
    }
}
