package com.example.vinylcollection.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.vinylcollection.data.model.CollectionStats
import com.example.vinylcollection.data.model.VinylRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface VinylDao {
    @Query("SELECT * FROM records ORDER BY createdAt DESC")
    fun getAllRecords(): Flow<List<VinylRecord>>

    @Query("SELECT * FROM records WHERE isFavorite = 1 ORDER BY createdAt DESC")
    fun getFavorites(): Flow<List<VinylRecord>>

    @Query("""
        SELECT * FROM records
        WHERE artist LIKE '%' || :query || '%'
           OR album LIKE '%' || :query || '%'
           OR label LIKE '%' || :query || '%'
           OR barcode LIKE '%' || :query || '%'
        ORDER BY createdAt DESC
    """)
    fun search(query: String): Flow<List<VinylRecord>>

    @Query("""
        SELECT
            COUNT(*) AS totalRecords,
            COALESCE(SUM(CASE WHEN isFavorite = 1 THEN 1 ELSE 0 END), 0) AS favoritesCount,
            COALESCE(SUM(CASE WHEN barcode != '' THEN 1 ELSE 0 END), 0) AS withBarcodeCount,
            COALESCE(SUM(CASE WHEN estimatedMedianValue IS NOT NULL THEN 1 ELSE 0 END), 0) AS valuedCount,
            COALESCE(SUM(COALESCE(estimatedMedianValue, 0)), 0) AS totalMedianValue
        FROM records
    """)
    fun observeStats(): Flow<CollectionStats>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: VinylRecord): Long

    @Update
    suspend fun update(record: VinylRecord)

    @Delete
    suspend fun delete(record: VinylRecord)

    @Query("SELECT * FROM records WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): VinylRecord?
}
