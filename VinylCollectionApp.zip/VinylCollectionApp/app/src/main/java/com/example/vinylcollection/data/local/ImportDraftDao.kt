package com.example.vinylcollection.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.vinylcollection.data.model.ImportDraft
import kotlinx.coroutines.flow.Flow

@Dao
interface ImportDraftDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(draft: ImportDraft): Long

    @Query("SELECT * FROM import_drafts ORDER BY updatedAt DESC LIMIT 1")
    fun observeLatestDraft(): Flow<ImportDraft?>

    @Query("DELETE FROM import_drafts")
    suspend fun clear()
}
