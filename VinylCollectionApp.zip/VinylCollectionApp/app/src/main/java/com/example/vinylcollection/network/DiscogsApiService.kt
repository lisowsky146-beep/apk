package com.example.vinylcollection.network

import com.example.vinylcollection.data.model.DiscogsMarketplaceStats
import com.example.vinylcollection.data.model.DiscogsReleaseResponse
import com.example.vinylcollection.data.model.DiscogsSearchResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface DiscogsApiService {
    @GET("database/search")
    suspend fun searchReleases(
        @Query("token") token: String,
        @Query("type") type: String = "release",
        @Query("q") query: String? = null,
        @Query("barcode") barcode: String? = null,
        @Query("per_page") perPage: Int = 20
    ): DiscogsSearchResponse

    @GET("releases/{release_id}")
    suspend fun getRelease(
        @Path("release_id") releaseId: Int,
        @Query("token") token: String
    ): DiscogsReleaseResponse

    @GET("marketplace/stats/{release_id}")
    suspend fun getMarketplaceStats(
        @Path("release_id") releaseId: Int,
        @Query("token") token: String
    ): DiscogsMarketplaceStats
}
