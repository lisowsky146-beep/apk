package com.example.vinylcollection.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.vinylcollection.data.model.VinylRecord

@Composable
fun RecordCard(
    record: VinylRecord,
    onFavoriteClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(record.artist, style = MaterialTheme.typography.titleMedium)
                    Text(record.album, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        listOfNotNull(
                            record.year?.toString(),
                            record.label.takeIf { it.isNotBlank() },
                            record.format.takeIf { it.isNotBlank() }
                        ).joinToString(" • "),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Row {
                    IconButton(onClick = onFavoriteClick) {
                        Icon(
                            imageVector = if (record.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "favorite"
                        )
                    }
                    IconButton(onClick = onDeleteClick) {
                        Icon(Icons.Default.Delete, contentDescription = "delete")
                    }
                }
            }
            if (record.barcode.isNotBlank()) {
                Text("Barcode: ${record.barcode}", style = MaterialTheme.typography.bodySmall)
            }
            if (record.estimatedMedianValue != null) {
                Text(
                    "Estimated value: $${"%.2f".format(record.estimatedMedianValue)}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            if (record.notes.isNotBlank()) {
                Text(record.notes.take(120), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
