@echo off
echo Wrapper file missing. Generate Gradle wrapper locally or add wrapper files before building.
exit /b 1
